import './style.css';

/* ===================================================================
   Lumière — Interactive JavaScript
   Modules: navbar, mobile menu, smooth scroll, scroll reveal,
   animated counters, menu filtering, lightbox, testimonial slider,
   countdown timer, form validation, scroll-to-top, dark mode toggle
   =================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initNavbar();
  initMobileMenu();
  initSmoothScroll();
  initScrollReveal();
  initCounters();
  initMenuFilter();
  initLightbox();
  initTestimonialSlider();
  initCountdown();
  initReservationForm();
  initNewsletter();
  initScrollToTop();
  initYear();
});

/* ============ DARK MODE ============ */
function initTheme() {
  const toggle = document.getElementById('theme-toggle');
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);

  toggle.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
  });
}

/* ============ STICKY NAVBAR ============ */
function initNavbar() {
  const navbar = document.getElementById('navbar');
  let ticking = false;

  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(() => {
        navbar.classList.toggle('scrolled', window.scrollY > 60);
        ticking = false;
      });
      ticking = true;
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

/* ============ MOBILE MENU ============ */
function initMobileMenu() {
  const hamburger = document.getElementById('hamburger');
  const navMenu = document.getElementById('nav-menu');

  hamburger.addEventListener('click', () => {
    const open = navMenu.classList.toggle('open');
    hamburger.classList.toggle('open', open);
    hamburger.setAttribute('aria-expanded', String(open));
    hamburger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });

  navMenu.querySelectorAll('.nav-link').forEach((link) => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    });
  });
}

/* ============ SMOOTH SCROLL + ACTIVE LINK ============ */
function initSmoothScroll() {
  const links = document.querySelectorAll('.nav-link');
  const sections = Array.from(links)
    .map((l) => document.querySelector(l.getAttribute('href')))
    .filter(Boolean);

  let ticking = false;
  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(() => {
        const pos = window.scrollY + 120;
        let current = sections[0]?.id;
        sections.forEach((sec) => {
          if (sec.offsetTop <= pos) current = sec.id;
        });
        links.forEach((l) =>
          l.classList.toggle('active', l.getAttribute('href') === `#${current}`)
        );
        ticking = false;
      });
      ticking = true;
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
}

/* ============ SCROLL REVEAL ============ */
function initScrollReveal() {
  const items = document.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  items.forEach((item) => observer.observe(item));
}

/* ============ ANIMATED COUNTERS ============ */
function initCounters() {
  const stats = document.querySelectorAll('.stat-num');
  let animated = false;

  const observer = new IntersectionObserver(
    (entries) => {
      if (entries[0].isIntersecting && !animated) {
        animated = true;
        stats.forEach(animateCounter);
      }
    },
    { threshold: 0.4 }
  );

  const statsSection = document.querySelector('.stats');
  if (statsSection) observer.observe(statsSection);
}

function animateCounter(el) {
  const target = parseInt(el.dataset.target, 10);
  const duration = 2000;
  const start = performance.now();

  function update(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = Math.floor(eased * target);
    el.textContent = value.toLocaleString();
    if (progress < 1) requestAnimationFrame(update);
    else el.textContent = target.toLocaleString();
  }

  requestAnimationFrame(update);
}

/* ============ MENU FILTERING ============ */
function initMenuFilter() {
  const buttons = document.querySelectorAll('.filter-btn');
  const cards = document.querySelectorAll('.menu-card');

  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      buttons.forEach((b) => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');

      const filter = btn.dataset.filter;
      cards.forEach((card) => {
        const show = filter === 'all' || card.dataset.category === filter;
        card.classList.toggle('hide', !show);
      });
    });
  });
}

/* ============ LIGHTBOX ============ */
function initLightbox() {
  const items = document.querySelectorAll('.masonry-item');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-img');
  const closeBtn = document.getElementById('lightbox-close');

  items.forEach((item) => {
    item.addEventListener('click', () => {
      lightboxImg.src = item.dataset.full || item.src;
      lightboxImg.alt = item.alt;
      lightbox.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  function close() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }

  closeBtn.addEventListener('click', close);
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) close();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && lightbox.classList.contains('open')) close();
  });
}

/* ============ TESTIMONIAL SLIDER ============ */
function initTestimonialSlider() {
  const slides = document.querySelectorAll('.slide');
  const dotsContainer = document.getElementById('slider-dots');
  const prev = document.getElementById('prev-slide');
  const next = document.getElementById('next-slide');
  let index = 0;
  let timer;

  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goTo(i));
    dotsContainer.appendChild(dot);
  });

  function goTo(n) {
    slides[index].classList.remove('active');
    dotsContainer.children[index].classList.remove('active');
    index = (n + slides.length) % slides.length;
    slides[index].classList.add('active');
    dotsContainer.children[index].classList.add('active');
    resetTimer();
  }

  function nextSlide() {
    goTo(index + 1);
  }

  function prevSlide() {
    goTo(index - 1);
  }

  function resetTimer() {
    clearInterval(timer);
    timer = setInterval(nextSlide, 5000);
  }

  next.addEventListener('click', nextSlide);
  prev.addEventListener('click', prevSlide);
  resetTimer();
}

/* ============ COUNTDOWN TIMER ============ */
function initCountdown() {
  const target = new Date();
  target.setDate(target.getDate() + 7);
  target.setHours(23, 59, 59, 0);

  const days = document.getElementById('cd-days');
  const hours = document.getElementById('cd-hours');
  const mins = document.getElementById('cd-mins');
  const secs = document.getElementById('cd-secs');

  function tick() {
    const diff = target - new Date();
    if (diff <= 0) {
      days.textContent = hours.textContent = mins.textContent = secs.textContent = '00';
      clearInterval(interval);
      return;
    }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    days.textContent = String(d).padStart(2, '0');
    hours.textContent = String(h).padStart(2, '0');
    mins.textContent = String(m).padStart(2, '0');
    secs.textContent = String(s).padStart(2, '0');
  }

  tick();
  const interval = setInterval(tick, 1000);
}

/* ============ RESERVATION FORM VALIDATION ============ */
function initReservationForm() {
  const form = document.getElementById('reservation-form');
  const success = document.getElementById('form-success');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;
    const fields = ['name', 'email', 'phone', 'guests', 'date', 'time'];

    fields.forEach((id) => {
      const input = document.getElementById(id);
      const error = document.getElementById(`${id}-error`);
      const value = input.value.trim();

      if (!value) {
        setFieldError(input, error, 'This field is required');
        valid = false;
      } else if (id === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        setFieldError(input, error, 'Please enter a valid email');
        valid = false;
      } else if (id === 'phone' && !/^[\d\s+\-()]{7,}$/.test(value)) {
        setFieldError(input, error, 'Please enter a valid phone number');
        valid = false;
      } else if (id === 'date') {
        const selected = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (selected < today) {
          setFieldError(input, error, 'Please select a future date');
          valid = false;
        } else {
          clearFieldError(input, error);
        }
      } else {
        clearFieldError(input, error);
      }
    });

    if (valid) {
      success.textContent = 'Reservation confirmed! We look forward to welcoming you.';
      form.reset();
      setTimeout(() => (success.textContent = ''), 6000);
    }
  });

  function setFieldError(input, error, msg) {
    input.classList.add('error');
    error.textContent = msg;
  }

  function clearFieldError(input, error) {
    input.classList.remove('error');
    error.textContent = '';
  }
}

/* ============ NEWSLETTER ============ */
function initNewsletter() {
  const form = document.getElementById('newsletter-form');
  const email = document.getElementById('newsletter-email');
  const msg = document.getElementById('newsletter-msg');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
      msg.textContent = 'Thank you for subscribing!';
      form.reset();
      setTimeout(() => (msg.textContent = ''), 5000);
    } else {
      msg.textContent = 'Please enter a valid email address.';
    }
  });
}

/* ============ SCROLL TO TOP ============ */
function initScrollToTop() {
  const btn = document.getElementById('scroll-top');
  let ticking = false;

  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(() => {
        btn.classList.toggle('show', window.scrollY > 500);
        ticking = false;
      });
      ticking = true;
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* ============ FOOTER YEAR ============ */
function initYear() {
  document.getElementById('year').textContent = new Date().getFullYear();
}
